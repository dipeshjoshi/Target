#!/bin/bash
set -vx

export wf_name=$1
export wf_id=$2
export wf_app_path=$3
export WF_BEGIN_TIME=$4
export WF_MONITOR_DB=$5
export WF_MONITOR_DB_DIR=$6
export HIVE_RUNTIME_DB=$7
export wf_user=$8
export wf_last_error_node=$9
export wf_error_code=${10}
export wf_error_msg=${11}
export queueName=${12}

WF_BEGIN_TIME=`hive -e "
SET mapreduce.job.queuename=${queueName};
SET mapreduce.job.credentials.binary=${HADOOP_TOKEN_FILE_LOCATION};
select current_timestamp;"`

`hive -e "
SET mapreduce.job.queuename=${queueName};
SET mapreduce.job.credentials.binary=${HADOOP_TOKEN_FILE_LOCATION};
CREATE DATABASE IF NOT EXISTS ${WF_MONITOR_DB} LOCATION '${WF_MONITOR_DB_DIR}';
CREATE TABLE IF NOT EXISTS ${WF_MONITOR_DB}.workflow_log
(
wf_name STRING
,wf_id STRING
,app_path STRING
,hive_runtime_db STRING
,begin_t STRING
,end_t STRING
,duration_min DOUBLE
,app_user STRING
,last_error_node STRING
,error_code STRING
,error_message STRING
)STORED AS PARQUET tblproperties ('parquet.compression'='SNAPPY');
"`

`hive -e "SET mapreduce.job.queuename=${queueName};
SET mapreduce.job.credentials.binary=${HADOOP_TOKEN_FILE_LOCATION};
INSERT INTO TABLE ${WF_MONITOR_DB}.workflow_log 
SELECT wf_name,
wf_id,
app_path,
hive_runtime_db,
begin_t,
NULL,
NULL,
app_user,
last_error_node,
error_code,
error_message
FROM (
 SELECT CAST('${wf_name}' AS STRING) AS wf_name,
 CAST('${wf_id}' AS STRING) AS wf_id,
 CAST('${wf_app_path}' AS STRING) AS app_path,
 CAST('${HIVE_RUNTIME_DB}' AS STRING) AS hive_runtime_db,
 CAST('${WF_BEGIN_TIME}' AS STRING) AS begin_t,
 CAST('${WF_END_TIME}' AS STRING) AS end_t,
 CAST('${wf_user}'AS STRING) AS app_user,
 CAST('${wf_last_error_node}' AS STRING) AS last_error_node,
 CAST('${wf_error_code}' AS STRING) AS error_code,
 CAST('${wf_error_msg}' AS STRING) AS error_message
) AS A;
"`

echo WF_BEGIN_TIME=$WF_BEGIN_TIME

