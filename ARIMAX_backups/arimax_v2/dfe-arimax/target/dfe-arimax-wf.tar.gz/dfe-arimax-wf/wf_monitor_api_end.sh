#!/bin/bash
set -vx

export wf_name=$1
export wf_id=$2
export wf_app_path=$3
export WF_BEGIN_TIME=$4
export WF_MONITOR_DB=$5
export HIVE_RUNTIME_DB=$6
export wf_user=$7
export wf_last_error_node=$8
export wf_error_code=$9
export wf_error_msg=${10}
export queueName=${11}

if [ -z "${wf_name}" ] || [ -z "${wf_id}" ] || [ -z "${wf_app_path}" ] || [ -z "${WF_BEGIN_TIME}" ] || [ -z "${wf_user}" ] || [ -z "${queueName}" ]
then
#  usage
	echo "All parameters are mandatory"
	exit 1
fi

if [ -z "${WF_MONITOR_DB}" ]
then
	WF_MONITOR_DB=NULL
fi

if [ -z "${HIVE_RUNTIME_DB}" ]
then
	HIVE_RUNTIME_DB=NULL
fi

if [ -z "${wf_last_error_node}" ]
then
	wf_last_error_node=NULL
fi

if [ -z "${wf_error_code}" ]
then
	wf_error_code=NULL
fi	

if [ -z "${wf_error_msg}" ]
then
	wf_error_msg=NULL
fi	

if [ -z "${wf_error_msg}" ]
then
	wf_error_msg=NULL
fi	

WF_END_TIME=`hive -e "
SET mapreduce.job.queuename=${queueName};
SET mapreduce.job.credentials.binary=${HADOOP_TOKEN_FILE_LOCATION};
select current_timestamp;
"`

if [ -z "${WF_END_TIME}" ]
then
#  usage
	echo "All parameters are mandatory" WF_END_TIME=${WF_END_TIME}
	exit 1
fi


`hive -e "SET mapreduce.job.queuename=${queueName};
SET mapreduce.job.credentials.binary=${HADOOP_TOKEN_FILE_LOCATION};
CREATE TABLE IF NOT EXISTS ${WF_MONITOR_DB}.workflow_log(
wf_name STRING
, wf_id STRING
, app_path STRING
, hive_runtime_db STRING
, begin_t STRING
, end_t STRING
, duration_min DOUBLE
, app_user STRING
, last_error_node STRING
, error_code STRING
, error_message STRING);
INSERT INTO TABLE ${WF_MONITOR_DB}.workflow_log 
SELECT wf_name,
wf_id,
app_path,
hive_runtime_db,
begin_t,
end_t,
CAST (unix_timestamp(end_t)-unix_timestamp(begin_t) AS DOUBLE)/60 as duration_min,
app_user,
last_error_node,
error_code,
error_message
FROM (
 SELECT CAST('${wf_name}' AS STRING) AS wf_name,
 CAST('${wf_id}' AS STRING) AS wf_id,
 CAST('${wf_app_path}' AS STRING) AS app_path,
 CAST('${HIVE_RUNTIME_DB}' AS STRING) AS hive_runtime_db,
 CAST('${WF_BEGIN_TIME}' AS STRING) AS begin_t,
 CAST('${WF_END_TIME}' AS STRING) AS end_t,
 CAST('${wf_user}'AS STRING) AS app_user,
 CAST('${wf_last_error_node}' AS STRING) AS last_error_node,
 CAST('${wf_error_code}' AS STRING) AS error_code,
 CAST('${wf_error_msg}' AS STRING) AS error_message
) AS A;
"`

